#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include<ctype.h>
#include<time.h>
#include "services.h"
struct date{
    int day,month,year;
    };
struct {
   char name[60];
    char lname[60];
    int acc_no,age;
    char address[60];
    double phone;
    float amt;
    struct date dob;
    struct date deposit;
    struct date join;
    struct date withdraw;
    float credit;
    float debit;
    float balance;
    char time[256];
    }add,upd,check,rem,transaction,pass;

void calcTime(char *str) {
        time_t ts;
        ts = time(NULL);
        strcpy(str, ctime(&ts));
        str[strlen(str) - 1] = '\0';
        return;
  }

void new_acc()
{
    system("cls");
    int ans=0,flag=0,i;
    char temp_fname[60],temp_lname[60];
FILE *ptr;
ptr=fopen("record.dat", "a+");

        system("cls");
            printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tADD RECORD\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\t\t\t_________________________________________________________________________");
            printf("\n\t\t\t*************************************************************************");

            srand(time(NULL));
            add.acc_no=229900 + rand()%99 + 10;

        name:
                flag=0;
                printf("\n\t\t\tEnter first name:");
                scanf("%s",add.name);
                flag=getvalidname(add.name);
                if(flag>=1)
                {
                    printf("\n\t\t\tInvalid input, Name should contain only characters");
                    goto name;
                }
                else{

                        flag=0;
                        printf("\n\t\t\tEnter last name:");
                        scanf("%s",add.lname);
                        flag=getvalidname(add.lname);

                         if(flag>=1)
                        {
                            printf("\n\t\t\tInvalid input, Name should contain only characters");
                            goto name;
                        }
                else{
            dob:
                printf("\n\t\t\tEnter the date of birth(dd/mm/yyyy)Age limit 100:");
                scanf("%d/%d/%d",&add.dob.day,&add.dob.month,&add.dob.year);
                int valid=0;
                /*
                valid=getValidintdate(add.dob.day);
                int valid_sum=valid;
                valid=getValidintdate(add.dob.month);
                valid_sum=valid_sum+valid;
                valid=getValidintdate(add.dob.year);
                valid_sum=valid_sum+valid;

                if(valid_sum>=1)
                {
                    printf("\n\t\t\tInvalid Input,Date should be of type integer");
                }

                else{*/
                valid=0;
                valid=validdate(add.dob.day,add.dob.month,add.dob.year);
                if(valid!=0)
                {
                    printf("\n\t\t\tInvalid Date!");

                    goto dob;
                }
                else{
                add.age=age(add.dob.day,add.dob.month,add.dob.year);
address:
                flag=0;
                printf("\n\t\t\tEnter the address:");
                scanf("%s",add.address);

                flag=getvalidname(add.address);
                if(flag>=1)
                {
                    printf("\n\t\t\tInvalid! Characters Expected!");
                    goto address;
                }
                else{


    phone:
                printf("\n\t\t\tEnter the phone number: ");
                add.phone=validphone();
                amount:
                printf("\n\t\t\tEnter the amount to deposit:$");
                add.amt=getValidInteger();
                if (add.amt>0)
                {
                    FILE *passbk;
                   passbk=fopen("pass.dat","ab+");
                    pass.acc_no=add.acc_no;
                    pass.credit=add.amt;
                    pass.balance=add.amt;
                    pass.debit=0;
                    calcTime(pass.time);
                    //count++;
                        fwrite(&pass,sizeof(pass),1,passbk);
                        fclose(passbk);
                }
                else
                {
                    printf("\n\t\t\tAmmount cannot be less than or equal to zero");
                    Sleep(200);
                }
                fprintf(ptr,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
                system("cls");
                printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tAccount Details\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
                printf("\n\t\t\t*************************************************************************");
                printf("\n\t\t\t_________________________________________________________________________");
                printf("\n\t\t\t*************************************************************************");
                printf("\n\t\t\tAccount No:%d",add.acc_no);
                printf("\n\t\t\tName:\t%s %s",add.name,add.lname);
                printf("\n\t\t\tD.O.B:\t%d/%d/%d",add.dob.day,add.dob.month,add.dob.year);
                printf("\n\t\t\tAge:\t%d",add.age);
                printf("\n\t\t\tAddress:%s",add.address);
                printf("\n\t\t\tContact No:%.0lf",add.phone);
                printf("\n\t\t\tAmount:%.2f",add.amt);

                fclose(ptr);
                printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=15;j++)
                {
                    Sleep(300);
                    printf(".");
                }
                }

                }

          }
        }
               system("cls");
                printf("\n\n\t\t\tACCOUNT CREATED SUCCESSFULLY!!");
                add_invalid:
                printf("\n\n\t\t\tPress 1 to add more records");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    new_acc();
                else if(ans==2)
                        menu();
                else if(ans==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid;
                    }
}
void view_list()
{
    system("cls");
    FILE *view;
    int ans=0,i=1;
    view=fopen("record.dat", "r");
    int count=0;

     printf("\n\t\t\tLOADING");
                for(int j=0;j<=15;j++)
                {
                    Sleep(100);
                    printf(".");
                }
                system("cls");
     printf("\n\n\t\t\t    \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tCustomer's List\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\t\t\t_________________________________________________________________________");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\n\n--------------------------------------------------------------------------------------------------------------------");
            printf("\n\t\t\tSR.NO.\tACC_NO.\t\tNAME\t\t\tADDRESS\t\tPHONE");
            printf("\n--------------------------------------------------------------------------------------------------------------------");
    while(fscanf(view,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
    {
        printf("\n\t\t\t%d.\t%d\t\t%s %s\t\t%s\t\t%.0lf ",i++,add.acc_no,add.name,add.lname,add.address,add.phone);
        count++;
    }
    fclose(view);
    if(count==0)
    {
        system("cls");
        printf("\n\t\t\tNO  RECORDS!!\n");
    }


    add_invalid:
                printf("\n\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    menu();
                else if(ans==0)
                        close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid;
                    }

}

void erase_acc(void)
{
   system("cls");
FILE *oldrec,*newrec,*deactrec;
int ans=0;
oldrec=fopen("record.dat","r");
newrec=fopen("new.dat","w");
deactrec=fopen("deactivate.dat","a+");
int count=0;
 printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tDEACTIVATE ACCOUNT\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
 printf("\n\t\t\t*************************************************************************");
 printf("\n\t\t\t_________________________________________________________________________");
 printf("\n\t\t\t*************************************************************************");
printf("\n\n\t\t\tEnter the account no. of the customer to deactivate the account:");
rem.acc_no=getValidInteger();
while(fscanf(oldrec,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
{
    if(add.acc_no!=rem.acc_no)
    {
        fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
    }
    else
    {
    fprintf(deactrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
        count++;
         printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=15;j++)
                {
                    Sleep(100);
                    printf(".");
                }
        printf("\n\n\t\t\tRECORD DEACTIVATED SUCCESSFULLY!!!\n");
    }
}

    fclose(deactrec);
       fclose(oldrec);
   fclose(newrec);
   remove("record.dat");
   rename("new.dat","record.dat");
    if(count==0)
    {
         printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=11;j++)
                {
                    Sleep(100);
                    printf(".");
                }
         printf("\n\n\t\t\tRECORD NOT FOUND!!");
          add_invalid:
                printf("\n\n\t\t\tPress 1 to try again");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    erase_acc();
                else if(ans==2)
                        menu();
                else if(ans==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid;
                    }
    }
    else
    {
         add_invalid1:
                printf("\n\t\t\tPress 1 to deactivate more accounts");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    erase_acc();
                else if(ans==2)
                        menu();
                else if(ans==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid1;
                    }
    }
}


void update_acc()
{
    system("cls");
    int ans=0,choice,test=0,flag=0,flag1=0;
    FILE *oldrec,*newrec;
    oldrec=fopen("record.dat","r");
    newrec=fopen("new.dat","w");
    printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tUPDATE RECORD\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\t_________________________________________________________________________");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\tEnter the account no. of the customer whose info you want to change\n\t\t\t");
    upd.acc_no=getValidInteger();
    while(fscanf(oldrec,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
    {
        if (add.acc_no==upd.acc_no)
        {   test=1;
            do
            {
                printf("\n\t\t\tWhich information do you want to change?\n\t\t\t1.Address\n\t\t\t2.Phone\n\n\t\t\tEnter your choice(1 for address and 2 for phone):");
                choice=getValidInteger();
                if(choice!=1 && choice!=2)
                    printf("\n\t\t\tInvalid Choice...! Try Again\a\n");
                else
                    flag=1;
            }while(flag==0);
            //system("cls");
            printf("\n\t\t\t************************\n");
            if(choice==1)
            {
        upd_address:
                printf("\n\t\t\tEnter the new address:");
                scanf("%s",upd.address);
                flag1=getvalidname(upd.address);
                if(flag1>=1)
                {
                    printf("\n\t\t\tInavlid Input!,Only Characters Expected");
                    goto upd_address;
                }
                else{
                fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,upd.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
                system("cls");
                printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=11;j++)
                {
                    Sleep(100);
                    printf(".");
                }
                printf("\n\t\t\tChanges saved!");
            }
            }
            else if(choice==2)
            {
            new_phone:
                printf("\n\t\t\tEnter the new phone number:");

                upd.phone=validphone();


                    fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,upd.phone,add.amt,add.join.day,add.join.month,add.join.year);
                    system("cls");
                    printf("\n\t\t\tPROCESSING");
                    for(int j=0;j<=11;j++)
                    {
                        Sleep(100);
                        printf(".");
                    }
                    printf("\n\t\t\tChanges saved!");

            }

        }
        else
            fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
    }
    fclose(oldrec);
    fclose(newrec);
    remove("record.dat");
    rename("new.dat","record.dat");

    if(test!=1)
    {
         printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=11;j++)
                {
                    Sleep(100);
                    printf(".");
                }
            system("cls");
            printf("\n\t\t\tRECORD NOT FOUND!!\a\a\a");

        add_invalid:
            printf("\n\n\t\t\tPress 1 to try again");
            printf("\n\t\t\tPress 2 to return to main menu");
            printf("\n\t\t\tPress 3 to exit");
            printf("\n\t\t\tEnter your choice: ");
            ans=getValidInteger();
            system("cls");
                if (ans==1)
                    update_acc();
                else if(ans==2)
                    menu();
                else if(ans==0)
                    close1();
                else
                    {
			printf("\n\t\t\tInvalid!\a");
			goto add_invalid;
		    }

        }
    else
        {
            add_inavalid:
            printf("\n\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
            ans=getValidInteger();
            system("cls");
            if(ans==1)
                menu();
            else if(ans==0)
                close1();
            else
            {
                printf("\n\t\t\tInvalid!\a");
                goto add_inavalid;
            }
        }
    }
//}







void transact()
{
    system("cls");
    int choice,test=0,ans,ans2;
    //static int count=0;
    int temp;
    int i;

    FILE *old,*newrec,*passbk;
    old=fopen("record.dat","r");
    newrec=fopen("new.dat","w");
      printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tTRANSCATION\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\t_________________________________________________________________________");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\tEnter the account no. of the customer: \n\t\t\t");
    transaction.acc_no=getValidInteger();
     while(fscanf(old,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
    {
        if(add.acc_no==transaction.acc_no)
        {
            temp=transaction.acc_no;
            pass.acc_no=transaction.acc_no;
            invalid:
                test=1;
             printf("\n\n\t\t\tDo you want to\n\t\t\t1.Deposit?\n\t\t\t2.Withdraw?\n\t\t\t3.Know The Account Summary\n\n\t\t\tEnter your choice: ");
                choice=getValidInteger();
                    printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=11;j++)
                {
                    Sleep(100);
                    printf(".");
                }
                system("cls");

                if (choice==1)
                {
                    add_invalidd:
                    printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tDEPOSIT\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
                    printf("\n\t\t\t*************************************************************************");
                    printf("\n\t\t\t_________________________________________________________________________");
                    printf("\n\t\t\t*************************************************************************");
                    passbk=fopen("pass.dat","ab+");
                    printf("\n\t\t\tEnter the amount you want to deposit:$ \n\t\t\t");
                    transaction.amt=getvalidfloat();
                     if(transaction.amt<=0){
                        printf("\n\n\t\t\tAmount cannot be less than or equal to zero!!\n");
                                   add_invalid5:
                printf("\n\n\t\t\tPress 1 to try again");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans2=getValidInteger();
                system("cls");
                if (ans2==1)
                    goto add_invalidd;
                else if(ans2==2)
                        menu();
                else if(ans2==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid5;
                    }
                    }
                   else{
                    add.amt+=transaction.amt;
                    pass.credit=transaction.amt;
                    pass.balance=add.amt;
                    pass.debit=0;
                    calcTime(pass.time);
                    //count++;
                        fwrite(&pass,sizeof(pass),1,passbk);
                        fclose(passbk);
                   }
                fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
                    printf("\n\n\t\t\tDEPOSITED SUCCESSFULLY!!");

                }
                else if(choice==2)
                {
                     add_invalid2:
                    printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tWITHDRAW\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
                    printf("\n\t\t\t*************************************************************************");
                    printf("\n\t\t\t_________________________________________________________________________");
                    printf("\n\t\t\t*************************************************************************");
                    passbk=fopen("pass.dat","ab+");
                    printf("\n\t\t\tEnter the amount you want to withdraw:$ \n\t\t\t");
                   // scanf("%f",&transaction.amt);
                    transaction.amt=getvalidfloat();
                    if(transaction.amt>add.amt)
                    {
                        printf("\n\n\t\t\tSorry you have insufficient balance to conduct this transaction!!\n");
                         add_invalid3:
                printf("\n\n\t\t\tPress 1 to try again");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans2=getValidInteger();
                system("cls");
                if (ans2==1)
                    goto add_invalid2;
                else if(ans2==2)
                        menu();
                else if(ans2==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid3;
                    }
                    }
                    else if(transaction.amt<=0){
                        printf("\n\n\t\t\tWithdrawn Amount cannot be less than or equal to zeo!!\n");
                                   add_invalid4:
                printf("\n\n\t\t\tPress 1 to try again");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans2=getValidInteger();
                system("cls");
                if (ans2==1)
                    goto add_invalid2;
                else if(ans2==2)
                        menu();
                else if(ans2==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid4;
                    }
                    }
                    else{
                    passbk=fopen("pass.dat","ab+");
                    add.amt-=transaction.amt;
                    pass.debit=transaction.amt;
                    pass.balance=add.amt;
                    pass.credit=0;
                    calcTime(pass.time);
                    //count++;
//                    printf("count: %d",count);
                fwrite(&pass,sizeof(pass),1,passbk);
                fclose(passbk);
                    }
                fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
                    printf("\n\n\t\t\tWITHDRAWN SUCCESSFULLY!!");
                }
                else if(choice ==3)
           {
                printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tACCOUNT SUMMARY\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
                    printf("\n\t\t\t*************************************************************************");
                    printf("\n\t\t\t_________________________________________________________________________");
                    printf("\n\t\t\t*************************************************************************");
                passbk=fopen("pass.dat","rb");
                    printf("\n\n\nTRANSACTION TIME\t\t\t DEPOSIT\t\t WITHDRAW\t\t BALANCE\n\n");
                    while( fread(&pass, sizeof(pass), 1, passbk) == 1)
                    {
                          if(temp==pass.acc_no)
                     printf("\n%s\t\t +%0.2f\t\t\t -%0.2f\t\t\t %0.2f", pass.time,pass.credit, pass.debit, pass.balance);

                    }

                    fclose(passbk);
               fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
           }

                else {
                    printf( "\nInvalid choice!!!\a");
                    goto invalid;
                }
            }
            else{
                fprintf(newrec,"\n\t\t\t%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",add.acc_no,add.name,add.lname,add.dob.day,add.dob.month,add.dob.year,add.age,add.address,add.phone,add.amt,add.join.day,add.join.month,add.join.year);
            }
    }
            fclose(old);
            fclose(newrec);
            remove("record.dat");
            rename("new.dat","record.dat");
             if(test!=1)
    {
         printf("\n\t\t\tPROCESSING");
                for(int j=0;j<=11;j++)
                {
                    Sleep(100);
                    printf(".");
                }
            system("cls");
       printf("\n\n\t\t\tRECORD NOT FOUND\a\a\a!!");
          add_invalid:
                printf("\n\n\t\t\tPress 1 to try again");
                printf("\n\t\t\tPress 2 to go to the main menu");
                printf("\n\t\t\tPress 3 to exit");
                printf("\n\t\t\tEnter your choice: ");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    transact();
                else if(ans==2)
                        menu();
                else if(ans==3)
                    close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid;
                    }
        }
    else
        {
            add_inavalid:
            printf("\n\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
            ans=getValidInteger();
            system("cls");
            if(ans==1)
                menu();
            else if(ans==0)
                close1();
            else
            {
                printf("\n\t\t\tInvalid!\a");
                goto add_inavalid;
            }
        }
        }


void view_deact()
{
     system("cls");
    FILE *view;
    int ans=0,i=1;
    view=fopen("deactivate.dat", "r");
    int count=0;

     printf("\n\t\t\tLOADING");
                for(int j=0;j<=15;j++)
                {
                    Sleep(100);
                    printf(".");
                }
                system("cls");
     printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tDeactivated Accounts\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\t\t\t_________________________________________________________________________");
            printf("\n\t\t\t*************************************************************************");
    printf("\n\n\t\tSR.NO.\tACC_NO.\t\tNAME\t\tADDRESS\t\tDOB\t\tAGE\tPHONE");
    while(fscanf(view,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
    {
        printf("\n\n\t\t%d\t%d\t   %s %s\t\t%s\t\t%d/%d/%d\t%d \t%.0lf ",i++,add.acc_no,add.name,add.lname,add.address,add.dob.day,add.dob.month,add.dob.year,add.age,add.phone);
        count++;
    }
    fclose(view);
    if(count==0)
    {
        system("cls");
        printf("\n\t\t\tNO  RECORDS!!\n");
    }


    add_invalid:
                printf("\n\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
                ans=getValidInteger();
                system("cls");
                if (ans==1)
                    menu();
                else if(ans==0)
                        close1();
                else
                    {
                        printf("\n\t\t\tInvalid!\a");
                        goto add_invalid;
                    }
}

void view_details()
{
     system("cls");
    FILE *ptr;
    int ans=0,choice,test=0,flag=0,flag1=0;
     printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tCustomer's Details\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\t_________________________________________________________________________");
    printf("\n\t\t\t*************************************************************************");
     printf("\n\t\t\tEnter the account no. of the customer whose details you want to see: ");
    check.acc_no=getValidInteger();
    ptr=fopen("record.dat","r");
     printf("\n\t\t\tLOADING");
                for(int j=0;j<=15;j++)
                {
                    Sleep(100);
                    printf(".");
                }
                system("cls");
            printf("\n\n\t\t\t    \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tCustomer's Details\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\t\t\t_________________________________________________________________________");
            printf("\n\t\t\t*************************************************************************");
            printf("\n\n");
              while(fscanf(ptr,"%d %s %s %d/%d/%d %d %s %lf %f %d/%d/%d ",&add.acc_no,add.name,add.lname,&add.dob.day,&add.dob.month,&add.dob.year,&add.age,add.address,&add.phone,&add.amt,&add.join.day,&add.join.month,&add.join.year)!=EOF)
    {
            if(add.acc_no==check.acc_no)
        {
        printf("\n\t\t\tAccount No.: %d\n\t\t\tName: %s %s\n\t\t\tAddress: %s\n\t\t\tDate Of Birth: %d/%d/%d\n\t\t\tAge: %d \n\t\t\tPhone No.: %.0lf\n\t\t\tBalance: %.2f ",add.acc_no,add.name,add.lname,add.address,add.dob.day,add.dob.month,add.dob.year,add.age,add.phone,add.amt);
        test=1;
        }
    }
     fclose(ptr);

     if(test!=1)
    {
            system("cls");
            printf("\n\t\t\tRECORD NOT FOUND!!\a\a\a");
        add_invalid:
            printf("\n\n\t\t\tPress 1 to try again");
            printf("\n\t\t\tPress 2 to return to main menu");
            printf("\n\t\t\tPress 3 to exit");
            printf("\n\t\t\tEnter your choice: ");
            ans=getValidInteger();
            system("cls");
                if (ans==1)
                    view_details();
                else if(ans==2)
                    menu();
                else if(ans==0)
                    close1();
                else
                    {
			printf("\n\t\t\tInvalid!\a");
			goto add_invalid;
		    }

        }
    else
        {
            add_inavalid:
            printf("\n\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
            ans=getValidInteger();
            system("cls");
            if(ans==1)
                menu();
            else if(ans==0)
                close1();
            else
            {
                printf("\n\t\t\tInvalid!\a");
                goto add_inavalid;
            }
        }
}
