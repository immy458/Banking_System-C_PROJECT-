#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include<string.h>
#include<conio.h>
//#include<dos.h>
#include "header.h"
//#define colo


void close1()
{
     system("cls");
    printf("\n\n\n\nThis C Mini Project is developed by Team Beta(Imtiyaz,Shubham,Eashan)!");
    printf("\n\n\nThank You!!\n\n\n");
    return 0;
}
int main()
{
    int flag=0;
    char password[20]="cproject",pass[50];
    char userid1[20]="eashan";
    char userid2[20]="immy";
    char userid3[20]="shubham";
    char pass1[20]="eashan123";
    char pass2[20]="immy123";
    char pass3[20]="shubham123";
    char username[20];
    int i,j,ans=0;
    system("color 2");
    printf("\n\n\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\t");

    printf("BANKING MANAGEMENT SYSTEM");
    printf("\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");

    printf("\n\t\t\t______________________________________________________________________");

    printf("\n\n\t\t\t\t\t\t\tLOGIN\n\n");
    printf("\n\n\t\t\tEnter Your User Id: ");
    scanf("%s",username);

    printf("\n\n\t\t\tEnter Your Password: ");
    int p=0;
    do{
        pass[p]=getch();
        if(pass[p]!='\r'){
            printf("*");
        }
        p++;
    }while(pass[p-1]!='\r');
    pass[p-1]='\0';

    if(strcmp(userid1,username)==0)
{
    if(strcmp(pass1,pass)==0)
    {
            printf("\n\n\t\t\tPASSWORD MATCHED!!");
            printf("\n\n\t\t\tHello, %s! \n",userid1);

          printf("\n\n\t\t\tLOADING");
           for(i=0;i<=15;i++)
            {
                Sleep(100);
                printf(".");
            }

            system("cls");
            menu();
    }
    else
        {
         printf("\n\n\t\t\tWrong Password!!\n\n");
        login_try2:
            printf("\n\t\t\tEnter 1 to try again and 0 to exit: ");
            scanf("%d",&ans);
            if(ans==1)
            {
                system("cls");
                main();
            }
            else if(ans==0)
            {
                system("cls");
                close1();
            }
            else
            {
                     printf("\n\n\t\t\tInvalid Input!!!");
              Sleep(2000);
                system("cls");
                goto login_try2;
            }
        }
}
else if(strcmp(userid2,username)==0)
{
    if(strcmp(pass2,pass)==0)
    {
            printf("\n\n\t\t\tPASSWORD MATCHED!!");
            printf("\n\n\t\t\tHello, %s! \n",userid2);

          printf("\n\n\t\t\tLOADING");
           for(i=0;i<=15;i++)
            {
                Sleep(100);
                printf(".");
            }

            system("cls");
            menu();
    }
    else
        {
         printf("\n\n\t\t\tWrong Password!!\n\n");
        login_try3:
            printf("\n\t\t\tEnter 1 to try again and 0 to exit: ");
            scanf("%d",&ans);
            if(ans==1)
            {
                system("cls");
                main();
            }
            else if(ans==0)
            {
                system("cls");
                close1();
            }
            else
            {
             printf("\n\n\t\t\tInvalid Input!!!");
              Sleep(2000);
                system("cls");
                goto login_try3;
            }
        }
}
else if(strcmp(userid3,username)==0)
{
    if(strcmp(pass3,pass)==0)
    {
            printf("\n\n\t\t\tPASSWORD MATCHED!!");
             printf("\n\n\t\t\tHello, %s! \n",userid3);
          printf("\n\n\t\t\tLOADING");
           for(i=0;i<=15;i++)
            {
                Sleep(100);
                printf(".");
            }

            system("cls");
            menu();
    }
    else
        {
         printf("\n\n\t\t\tWrong Password!!\n\n");
        login_try4:
            printf("\n\t\t\tEnter 1 to try again and 0 to exit: ");
            scanf("%d",&ans);
            if(ans==1)
            {
                system("cls");
                main();
            }
            else if(ans==0)
            {
                system("cls");
                close1();
            }
            else
            {
            printf("\n\n\t\t\tInvalid Input!!!");
              Sleep(2000);
                system("cls");
                goto login_try4;
            }
        }
}
else{
      printf("\n\n\n\t\t\tYou have entered invalid User Id!!!\n\n");
        login_try5:
            printf("\n\t\t\tEnter 1 to try again and 0 to exit: ");
            scanf("%d",&ans);
            if(ans==1)
            {
                system("cls");
                main();
            }
            else if(ans==0)
            {
                system("cls");
                close1();
            }
            else
            {
             printf("\n\n\t\t\tInvalid Input!!!");
              Sleep(2000);
                system("cls");
                goto login_try5;
            }
        }

}




