#include<stdio.h>
#include "services.h"
void menu()
{
    int choice;
    int c=1;
    system("cls");
    printf("\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\t\tBANK NAME\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\t\t\t_________________________________________________________________________");
    printf("\n\t\t\t*************************************************************************");
    printf("\n\n\n\t\t\tWELCOME TO THE MAIN MENU ");
    printf("\n\t\t\t************************");
    printf("\n\t\t\t1.Create new account\n\t\t\t2.Update information of existing account\n\t\t\t3.For transactions\n\t\t\t4.Check the details of existing account\n\t\t\t5.View customer's list\n\t\t\t6.Deactivate existing account\n\t\t\t7.View Deactivated Accounts.\n\t\t\t8.Exit");
    printf("\n\t\t\t************************");
    choice:
            printf("\n\n\n\t\t\tEnter your choice: ");
            choice=getValidInteger();
            switch(choice)
{
        case 1:new_acc();
        break;
        case 2:update_acc();
        break;
        case 3:transact();
        break;
        case 4: view_details();
        break;
        case 5:view_list();
        break;
        case 6:erase_acc();
        break;
        case 7:view_deact();
        break;
        case 8:close1();
        break;
        default:printf("\n\t\t\tInvalid Input! TRY AGAIN");
                goto choice;
        break;
}
   // }while(c==1);
}
