#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "services.h"
#include<time.h>
#include<string.h>



int getValidInteger()
{
	char str[10];
	int l,i;
	short int flag=0;
	choice:
	do{
		scanf("%s",str);
		l=strlen(str);

		if(str[0]=='+' || str[0]=='-' || (isdigit(str[0])))
		{
			flag=1;
		}
		//End If

		if(flag==1)
		{

			for(i=1;i<l;i++)
			{
				if(str[i]<'0' || str[i]>'9')
				{
					flag=0;
					break;
				}
				//End if
			}
			//End For Loop
		}
		//End If

		if(flag==1)
		{
			return(atoi(str));
		}
		//End If
		else
		{
			printf("\n\t\t\t\aInappropriate Input(Digit expected)");
			printf("\n\t\t\tPlease Enter a Valid Input:\a ");
			goto choice;
		}
		//End Else

	}
	while(flag==0);
	//End Do While Loop

}

char getvalidname(char str[50])
{
    int i,flag=0;
    //char fname[50],lname[50];


    for(i=0;i<strlen(str);i++)
    {

        if((str[i]>='a' && str[i]<='z') || (str[i]>='A' && str[i]<='Z'))
        {
            flag=flag+0;
            //return flag ;
        }
        else{
            flag=flag+1;
            //return flag;
        }
    }

    if(flag>=1)
    {
       return flag;
    }
    else{
        flag=0;
        return flag;
    }

}

int isLeapYear(int year, int mon)
{
    int flag = 0;
    if (year % 100 == 0)
    {
            if (year % 400 == 0)
            {
                    if (mon == 2)
                    {
                            flag = 1;
                    }
            }
    }
    else if (year % 4 == 0)
    {
            if (mon == 2)
            {
                    flag = 1;
            }
    }
    return (flag);
}
int age(int day,int months,int years)
{
     int DaysInMon[] = {31, 28, 31, 30, 31, 30,
                       31, 31, 30, 31, 30, 31};
    int days=day, month=months, year=years;
    char dob[100];
    time_t ts;
    struct tm *ct;

    /* enter date of birth */
   // printf("Enter your date of birth (DD/MM/YYYY): ");
    //scanf("\n\t\t\t%d/%d/%d",&days,&month, &year);

    /*get current date.*/
    ts = time(NULL);
    ct = localtime(&ts);

    //printf("Current Date: %d/%d/%d\n",
           // ct->tm_mday, ct->tm_mon + 1, ct->tm_year + 1900);

    days = DaysInMon[month - 1] - days + 1;

    /* leap year checking*/
    if (isLeapYear(year, month))
    {
            days = days + 1;
    }

    /* calculating age in no of days, years and months */
    days = days + ct->tm_mday;
    month = (12 - month) + (ct->tm_mon);
    year = (ct->tm_year + 1900) - year - 1;

    /* checking for leap year feb - 29 days */
    if (isLeapYear((ct->tm_year + 1900), (ct->tm_mon + 1)))
    {
            if (days >= (DaysInMon[ct->tm_mon] + 1))
            {
                    days = days - (DaysInMon[ct->tm_mon] + 1);
                    month = month + 1;
            }
    }
    else if (days >= DaysInMon[ct->tm_mon])
    {
            days = days - (DaysInMon[ct->tm_mon]);
            month = month + 1;
    }

    if (month >= 12)
    {
            year = year + 1;
            month = month - 12;
    }

    /* print age */
    //printf("\n## Hey you are  %d years %d months and %d days old. ##\n", year, month, days);

    return year;
}

int validdate(int days_check, int months_check, int years_check)
{
    int day=days_check,month=months_check,year=years_check,count=0,flag=0;
    int currentyear,difference;
    struct tm *current;
    int temp_day=day;
    while(temp_day!=0)
    {
        temp_day/=10;
        count ++;
    }
    if(count>2)
    {
        flag=1;
       // return flag;

    }
    else {
            if(day==31)
            {
                if(month==4 || month==5 || month==6 || month==9|| month==11)
                {


                flag=1;
                //return flag;
                }
                else{
                    flag=0;
                }

            }
            else if(day>28 && month==2)
            {
                flag=1;
                //return flag;

            }
            else if(day<1 || day>31)
            {
                flag=1;
               // return flag;

            }
            else{
                flag=0;
                //return flag;

            }
        }
        if(flag==1)
        {
            return flag;

        }
    else{
        count=0;
    int temp_month=month;
    while(temp_month!=0)
    {
        temp_month/=10;
        count ++;
    }
    if(count>2)
    {
        flag=1;
        //return flag;

    }
    else {
        if(month<1 || month>12)
        {
            flag=1;
            //return flag;

        }
        else{
            flag=0;
            //return flag;

        }
    }
    if(flag==1)
    {
        return flag;
    }
    else{
    count=0;
    int temp_year=year;
    while(temp_year!=0)
    {
        temp_year/=10;
        count ++;
    }
    if(count<4 || count>4)
    {
        flag=1;
        //return flag;

    }

    else{

        time_t timenow;
        time(&timenow);
        current = localtime(&timenow);

        currentyear = current->tm_year+1900;
        difference=currentyear-year;

        if(year>currentyear || difference>100)
        {
            flag=1;
            //return flag;

        }
        else{
            flag=0;
            //return flag;

        }

    }

        return flag;
    }
    }
}

int getValidintdate(int date)
{

	char str[10];
	int l,i;
	short int flag=0;
	choice:
	do{
		sprintf(str,"%d",date);
		l=strlen(str);

		if(str[0]=='+' || str[0]=='-' || (isdigit(str[0])))
		{
			flag=1;
		}
		//End If

		if(flag==1)
		{

			for(i=1;i<l;i++)
			{
				if(str[i]<'0' || str[i]>'9')
				{
					flag=0;
					return flag;
					break;
				}
				//End if
			}
			//End For Loop
		}
		//End If

		if(flag==1)
		{
			return flag;
		}
		//End If
		else
		{
		    return flag;
		}
		//End Else

	}
	while(flag==0);
	//End Do While Loop


}

int getvalidfloat()
{
	char str[10];
	int l,i;
	short int flag=0;
	choice:
	do{
		scanf("%s",str);
		l=strlen(str);

		if(str[0]=='+' || str[0]=='-' || (isdigit(str[0])))
		{
			flag=1;
		}
		//End If

		if(flag==1)
		{

			for(i=1;i<l;i++)
			{
				if(str[i]<'0' || str[i]>'9')
				{
					flag=0;
					break;
				}
				//End if
			}
			//End For Loop
		}
		//End If

		if(flag==1)
		{
			return(atof(str));
		}
		//End If
		else
		{
			printf("\n\t\t\t\aInappropriate Input(Digit expected)");
			printf("\n\t\t\tPlease Enter a Valid Input:\a ");
			goto choice;
		}
		//End Else

	}
	while(flag==0);
	//End Do While Loop

}

double validphone()
{

    char str[10];
	int l,i;
	short int flag=0;


	choice:
	do{
		scanf("%s",str);
		l=strlen(str);
		if(l==10 )
        {



		if(str[0]=='+' || str[0]=='-' || (isdigit(str[0])))
		{
			flag=1;
		}
		//End If

		if(flag==1)
		{

			for(i=1;i<l;i++)
			{
				if(str[i]<'0' || str[i]>'9')
				{
					flag=0;
					break;
				}
				//End if
			}
			//End For Loop
		}
		//End If

		if(flag==1)
		{
			return((strtod(str,NULL)));
		}

		//End If
		else
		{
			printf("\n\t\t\t\aInappropriate Input(Digit expected)");
			printf("\n\t\t\tPlease Enter a Valid Input:\a ");
			goto choice;
		}
        }
		else{
            printf("\n\t\t\t\aPhone Number Should be of only of 10 digits");
            printf("\n\t\t\tEnter Again: ");
            goto choice;
		}
		//End Else

	}
	while(flag==0);
	//End Do While Loop
}

